module.exports = require('./build/lib/index.js');
