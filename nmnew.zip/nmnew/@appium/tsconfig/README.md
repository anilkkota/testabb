# @appium/tsconfig

> Shared TypeScript Config for Appium

## Motivation

Appium projects and extensions are encouraged to use these settings.

## Install

```bash
npm install appium @appium/tsconfig -D
```

[appium](https://npm.im/appium) is a peer dependency of this package.

## License

Apache-2.0
