module.exports = require('./build/lib/constraints');
