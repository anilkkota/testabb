import {type Constraints} from '@appium/types';

export const ANDROID_DRIVER_CONSTRAINTS = {
  platformName: {
    isString: true,
    inclusionCaseInsensitive: ['Android'],
    presence: true,
  },
  deviceName: {
    isString: true,
  },
  appActivity: {
    isString: true,
  },
  appPackage: {
    isString: true,
  },
  appWaitActivity: {
    isString: true,
  },
  appWaitPackage: {
    isString: true,
  },
  appWaitDuration: {
    isNumber: true,
  },
  deviceReadyTimeout: {
    isNumber: true,
  },
  androidDeviceReadyTimeout: {
    isNumber: true,
  },
  androidDeviceSocket: {
    isString: true,
  },
  androidInstallTimeout: {
    isNumber: true,
  },
  adbPort: {
    isNumber: true,
  },
  remoteAdbHost: {
    isString: true,
  },
  adbExecTimeout: {
    isNumber: true,
  },
  avd: {
    isString: true,
  },
  avdLaunchTimeout: {
    isNumber: true,
  },
  avdReadyTimeout: {
    isNumber: true,
  },
  avdArgs: {
    // could be a string or an array
  },
  avdEnv: {
    isObject: true,
  },
  useKeystore: {
    isBoolean: true,
  },
  keystorePath: {
    isString: true,
  },
  keystorePassword: {
    isString: true,
  },
  keyAlias: {
    isString: true,
  },
  keyPassword: {
    isString: true,
  },
  webviewDevtoolsPort: {
    isNumber: true,
  },
  ensureWebviewsHavePages: {
    isBoolean: true,
  },
  enableWebviewDetailsCollection: {
    isBoolean: true,
  },
  chromedriverPort: {
    isNumber: true,
  },
  chromedriverPorts: {
    isArray: true,
  },
  chromedriverArgs: {
    isObject: true,
  },
  chromedriverExecutable: {
    isString: true,
  },
  chromedriverExecutableDir: {
    isString: true,
  },
  chromedriverChromeMappingFile: {
    isString: true,
  },
  chromedriverUseSystemExecutable: {
    isBoolean: true,
  },
  chromedriverDisableBuildCheck: {
    isBoolean: true,
  },
  chromeLoggingPrefs: {
    isObject: true,
  },
  autoWebviewTimeout: {
    isNumber: true,
  },
  autoWebviewName: {
    isString: true,
  },
  intentAction: {
    isString: true,
  },
  intentCategory: {
    isString: true,
  },
  intentFlags: {
    isString: true,
  },
  optionalIntentArguments: {
    isString: true,
  },
  dontStopAppOnReset: {
    isBoolean: true,
  },
  /** @deprecated Use hideKeyboard instead */
  unicodeKeyboard: {
    isBoolean: true,
  },
  hideKeyboard: {
    isBoolean: true,
  },
  noSign: {
    isBoolean: true,
  },
  recreateChromeDriverSessions: {
    isBoolean: false,
  },
  autoLaunch: {
    isBoolean: true,
  },
  nativeWebScreenshot: {
    isBoolean: true,
  },
  clearSystemFiles: {
    isBoolean: true,
  },
  extractChromeAndroidPackageFromContextName: {
    isBoolean: true,
  },
  autoGrantPermissions: {
    isBoolean: true,
  },
  networkSpeed: {
    isString: true,
  },
  gpsEnabled: {
    isBoolean: true,
  },
  isHeadless: {
    isBoolean: true,
  },
  showChromedriverLog: {
    isBoolean: true,
  },
  skipUnlock: {
    isBoolean: true,
  },
  clearDeviceLogsOnStart: {
    isBoolean: true,
  },
  unlockType: {
    isString: true,
  },
  unlockKey: {
    isString: true,
  },
  unlockStrategy: {
    isString: true,
    inclusionCaseInsensitive: ['locksettings', 'uiautomator'],
  },
  otherApps: {
    isString: true,
  },
  uninstallOtherPackages: {
    isString: true,
  },
  allowTestPackages: {
    isBoolean: true,
  },
  pageLoadStrategy: {
    isString: true,
  },
  localeScript: {
    isString: true,
  },
  skipDeviceInitialization: {
    isBoolean: true,
  },
  remoteAppsCacheLimit: {
    isNumber: true,
  },
  buildToolsVersion: {
    isString: true,
  },
  skipLogcatCapture: {
    isBoolean: true,
  },
  chromeOptions: {
    isObject: true,
  },
  enablePerformanceLogging: {
    isBoolean: true,
  },
  userProfile: {
    isNumber: true,
  },
  browserName: {
    isString: true,
  },
  enforceAppInstall: {
    isBoolean: true,
  },
  suppressKillServer: {
    isBoolean: true,
  },
  allowOfflineDevices: {
    isBoolean: true,
  },
  ignoreHiddenApiPolicyError: {
    isBoolean: true,
  },
  unlockSuccessTimeout: {
    isNumber: true,
  },
  mockLocationApp: {
    isString: true,
  },
  logcatFormat: {
    isString: true,
  },
  logcatFilterSpecs: {
    isArray: true,
  },
  allowDelayAdb: {
    isBoolean: true,
  },
  ignoreUnimportantViews: {
    isBoolean: true,
  },
  disableWindowAnimation: {
    isBoolean: true,
  },
  appWaitForLaunch: {
    isBoolean: true,
  },
} as const satisfies Constraints;

export default ANDROID_DRIVER_CONSTRAINTS;

export type AndroidDriverConstraints = typeof ANDROID_DRIVER_CONSTRAINTS;
