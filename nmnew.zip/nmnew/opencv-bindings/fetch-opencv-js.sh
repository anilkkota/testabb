#!/bin/bash

curl https://docs.opencv.org/$OPENCV_VERSION/opencv.js -o index.js
curl "https://lh3.googleusercontent.com/proxy/OCTDqE3UevUSwW24nPmr8LfqXioeo8szA2sIHpD4HuBCHrpWZi7_S8wHMa2Ak8_IqTw_ptEPdHL84-RAQBwI0BGZyI7pk9XAoKiAilJ4tKxtiwo" -o ./test/lena.jpg