declare const env: {
	__proto__: null,
	boundFnsHaveConfigurableLengths: boolean;
	boundFnsHaveWritableLengths: boolean;
	functionsHaveConfigurableLengths: boolean;
	functionsHaveWritableLengths: boolean;
};

export = env;